-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Springfield', '2018-05-17 06:00:20', '2018-05-17 06:00:20'),
(2, 'Agawam', '2018-05-17 06:00:54', '2018-05-17 06:00:54'),
(3, 'East  Longmeadow', '2018-05-17 06:01:19', '2018-05-17 06:01:19'),
(4, 'Longmeadow', '2018-05-17 06:01:34', '2018-05-17 06:01:34'),
(5, 'Chicopee', '2018-05-17 06:01:48', '2018-05-17 06:01:48'),
(6, 'Granby', '2018-05-17 06:01:57', '2018-05-17 06:01:57'),
(7, 'Granby', '2018-05-17 06:02:38', '2018-05-17 06:02:38'),
(8, 'Avon', '2018-05-17 06:02:50', '2018-05-17 06:02:50'),
(9, 'Enfield', '2018-05-17 06:02:57', '2018-05-17 06:02:57'),
(10, 'Sommers', '2018-05-17 06:03:09', '2018-05-17 06:03:09'),
(11, 'Sufield', '2018-05-17 06:03:22', '2018-05-17 06:03:22'),
(12, 'Westfield', '2018-05-17 06:03:38', '2018-05-17 06:03:38'),
(13, 'West Springfield', '2018-05-17 06:03:48', '2018-05-17 06:03:48'),
(14, 'Pittsfield', '2018-05-17 06:04:14', '2018-05-17 06:04:14'),
(15, 'Greenfield', '2018-05-17 06:04:33', '2018-05-17 06:04:33'),
(16, 'Brattleboro', '2018-05-17 06:05:15', '2018-05-17 06:05:15'),
(17, 'East Windsor', '2018-05-17 06:05:36', '2018-05-17 06:05:36'),
(18, 'Manchester', '2018-05-17 06:07:56', '2018-05-17 06:07:56'),
(19, 'Bloomfield', '2018-05-17 06:08:54', '2018-05-17 06:08:54'),
(20, 'Monson', '2018-05-17 06:09:06', '2018-05-17 06:09:06'),
(21, 'Wibraham', '2018-05-17 06:09:18', '2018-05-17 06:09:18'),
(22, 'Warren', '2018-05-17 06:34:35', '2018-05-17 06:34:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
