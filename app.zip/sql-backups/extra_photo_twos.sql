-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `extra_photo_twos`
--

CREATE TABLE `extra_photo_twos` (
  `id` int(10) UNSIGNED NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `extra_photo_twos`
--

INSERT INTO `extra_photo_twos` (`id`, `file`, `created_at`, `updated_at`) VALUES
(34, '1522460183pexels-photo-276508.jpg', '2018-03-31 06:36:23', '2018-03-31 06:36:23'),
(35, '1522460535pexels-photo-276551.jpeg', '2018-03-31 06:42:15', '2018-03-31 06:42:15'),
(36, '1522460785pexels-photo-261410.jpeg', '2018-03-31 06:46:25', '2018-03-31 06:46:25'),
(37, '1522460941pexels-photo-269218.jpeg', '2018-03-31 06:49:01', '2018-03-31 06:49:01'),
(38, '1522461134living-room-couch-interior-room-584399.jpeg', '2018-03-31 06:52:14', '2018-03-31 06:52:14'),
(39, '1522461277pexels-photo-257344.jpeg', '2018-03-31 06:54:37', '2018-03-31 06:54:37'),
(40, '1522785654pexels-photo-106936.jpeg', '2018-04-04 01:00:54', '2018-04-04 01:00:54'),
(41, '1522788571pexels-photo-271654.jpeg', '2018-04-04 01:49:31', '2018-04-04 01:49:31'),
(42, '1522788677pexels-photo-276653.jpeg', '2018-04-04 01:51:17', '2018-04-04 01:51:17'),
(43, '1526257734pexels-photo-259962.jpg', '2018-05-14 05:28:54', '2018-05-14 05:28:54'),
(44, '1526257861pexels-photo-273669.jpeg', '2018-05-14 05:31:01', '2018-05-14 05:31:01'),
(45, '1526257996pexels-photo-269262.jpg', '2018-05-14 05:33:16', '2018-05-14 05:33:16'),
(46, '1526519762pexels-photo-210552.jpeg', '2018-05-17 06:16:02', '2018-05-17 06:16:02'),
(47, '1526519937pexels-photo-77931.jpeg', '2018-05-17 06:18:57', '2018-05-17 06:18:57'),
(48, '1526520079pexels-photo-261410.jpeg', '2018-05-17 06:21:19', '2018-05-17 06:21:19'),
(49, '1526522366pexels-photo-238377.jpeg', '2018-05-17 06:59:26', '2018-05-17 06:59:26'),
(50, '1526522488pexels-photo-265004.jpeg', '2018-05-17 07:01:28', '2018-05-17 07:01:28'),
(51, '1526522618pexels-photo-265004.jpeg', '2018-05-17 07:03:38', '2018-05-17 07:03:38'),
(52, '1526522809living-room-couch-interior-room-584399.jpeg', '2018-05-17 07:06:49', '2018-05-17 07:06:49'),
(53, '1526523217pexels-photo-273822.jpeg', '2018-05-17 07:13:37', '2018-05-17 07:13:37'),
(54, '1526523393pexels-photo-271618.jpg', '2018-05-17 07:16:33', '2018-05-17 07:16:33'),
(55, '1526523545pexels-photo-238377.jpeg', '2018-05-17 07:19:05', '2018-05-17 07:19:05'),
(56, '1526523820pexels-photo-265004.jpeg', '2018-05-17 07:23:40', '2018-05-17 07:23:40'),
(57, '1526524107pexels-photo-77931.jpeg', '2018-05-17 07:28:27', '2018-05-17 07:28:27'),
(58, '1526524294pexels-photo-271795.jpeg', '2018-05-17 07:31:34', '2018-05-17 07:31:34'),
(59, '1526524449pexels-photo-238377.jpeg', '2018-05-17 07:34:09', '2018-05-17 07:34:09'),
(60, '1526524609pexels-photo-238377.jpeg', '2018-05-17 07:36:49', '2018-05-17 07:36:49'),
(61, '1526524856pexels-photo-261045.jpg', '2018-05-17 07:40:56', '2018-05-17 07:40:56'),
(62, '1526525131pexels-photo-189333.jpeg', '2018-05-17 07:45:31', '2018-05-17 07:45:31'),
(63, '1526525357pexels-photo-210552.jpeg', '2018-05-17 07:49:17', '2018-05-17 07:49:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `extra_photo_twos`
--
ALTER TABLE `extra_photo_twos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `extra_photo_twos`
--
ALTER TABLE `extra_photo_twos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
