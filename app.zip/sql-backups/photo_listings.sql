-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `photo_listings`
--

CREATE TABLE `photo_listings` (
  `id` int(10) UNSIGNED NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `photo_listings`
--

INSERT INTO `photoslisting` (`id`, `file`, `created_at`, `updated_at`) VALUES
(65, '1522460183pexels-photo-164516.jpg', '2018-03-31 06:36:23', '2018-03-31 06:36:23'),
(66, '1522460535pexels-photo-210617.jpg', '2018-03-31 06:42:15', '2018-03-31 06:42:15'),
(67, '1522460785pexels-photo-140511.jpeg', '2018-03-31 06:46:25', '2018-03-31 06:46:25'),
(68, '1522460941pexels-photo-210617.jpg', '2018-03-31 06:49:01', '2018-03-31 06:49:01'),
(69, '1522461134pexels-photo-534184.jpg', '2018-03-31 06:52:14', '2018-03-31 06:52:14'),
(70, '1522461277pexels-photo-139115.jpeg', '2018-03-31 06:54:37', '2018-03-31 06:54:37'),
(71, '1522785654pexels-photo-259098.jpg', '2018-04-04 01:00:54', '2018-04-04 01:00:54'),
(72, '1522788571pexels-photo-139115.jpeg', '2018-04-04 01:49:31', '2018-04-04 01:49:31'),
(73, '1522788677pexels-photo-209296.jpg', '2018-04-04 01:51:17', '2018-04-04 01:51:17'),
(74, '1526257734pexels-photo-206172.jpeg', '2018-05-14 05:28:54', '2018-05-14 05:28:54'),
(75, '1526257860pexels-photo-259646.jpg', '2018-05-14 05:31:00', '2018-05-14 05:31:00'),
(76, '1526257996pexels-photo-221024_1.jpg', '2018-05-14 05:33:16', '2018-05-14 05:33:16'),
(77, '1526519761pexels-photo-164539.jpeg', '2018-05-17 06:16:02', '2018-05-17 06:16:02'),
(78, '1526519937pexels-photo-164558.jpg', '2018-05-17 06:18:57', '2018-05-17 06:18:57'),
(79, '1526520079pexels-photo-259751.jpeg', '2018-05-17 06:21:19', '2018-05-17 06:21:19'),
(80, '1526522366pexels-photo-534184.jpg', '2018-05-17 06:59:26', '2018-05-17 06:59:26'),
(81, '1526522488pexels-photo-221024.jpg', '2018-05-17 07:01:28', '2018-05-17 07:01:28'),
(82, '1526522618large-home-residential-house-architecture-53610.jpeg', '2018-05-17 07:03:38', '2018-05-17 07:03:38'),
(83, '1526522809pexels-photo-280229.jpeg', '2018-05-17 07:06:49', '2018-05-17 07:06:49'),
(84, '1526523217pexels-photo-243722.jpg', '2018-05-17 07:13:37', '2018-05-17 07:13:37'),
(85, '1526523393pexels-photo-140511.jpeg', '2018-05-17 07:16:33', '2018-05-17 07:16:33'),
(86, '1526523545pexels-photo-139115.jpeg', '2018-05-17 07:19:05', '2018-05-17 07:19:05'),
(87, '1526523820pexels-photo-139115.jpeg', '2018-05-17 07:23:40', '2018-05-17 07:23:40'),
(88, '1526523868pexels-photo-164522.jpg', '2018-05-17 07:24:28', '2018-05-17 07:24:28'),
(89, '1526524107pexels-photo-164516.jpg', '2018-05-17 07:28:27', '2018-05-17 07:28:27'),
(90, '1526524294pexels-photo-206172.jpeg', '2018-05-17 07:31:34', '2018-05-17 07:31:34'),
(91, '1526524449pexels-photo-534184.jpg', '2018-05-17 07:34:09', '2018-05-17 07:34:09'),
(92, '1526524609pexels-photo-106399.jpg', '2018-05-17 07:36:49', '2018-05-17 07:36:49'),
(93, '1526524856pexels-photo-462358.jpg', '2018-05-17 07:40:56', '2018-05-17 07:40:56'),
(94, '1526525131pexels-photo-206673.jpeg', '2018-05-17 07:45:31', '2018-05-17 07:45:31'),
(95, '1526525357pexels-photo-139115.jpeg', '2018-05-17 07:49:17', '2018-05-17 07:49:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `photo_listings`
--
ALTER TABLE `photo_listings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `photo_listings`
--
ALTER TABLE `photo_listings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
