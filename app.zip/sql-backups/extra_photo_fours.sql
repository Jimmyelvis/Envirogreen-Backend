-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `extra_photo_fours`
--

CREATE TABLE `extra_photo_fours` (
  `id` int(10) UNSIGNED NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `extra_photo_fours`
--

INSERT INTO `extra_photo_fours` (`id`, `file`, `created_at`, `updated_at`) VALUES
(28, '1522460183pexels-photo-280208.jpg', '2018-03-31 06:36:23', '2018-03-31 06:36:23'),
(29, '1522460535pexels-photo-709767.png', '2018-03-31 06:42:15', '2018-03-31 06:42:15'),
(30, '1522460785pexels-photo-265004.jpeg', '2018-03-31 06:46:25', '2018-03-31 06:46:25'),
(31, '1522460941pexels-photo-271624.jpg', '2018-03-31 06:49:01', '2018-03-31 06:49:01'),
(32, '1522461134pexels-photo-276653.jpeg', '2018-03-31 06:52:14', '2018-03-31 06:52:14'),
(33, '1522461277pexels-photo-77931.jpeg', '2018-03-31 06:54:37', '2018-03-31 06:54:37'),
(34, '1522785654pexels-photo-273669.jpeg', '2018-04-04 01:00:54', '2018-04-04 01:00:54'),
(35, '1522788571pexels-photo-276551.jpeg', '2018-04-04 01:49:31', '2018-04-04 01:49:31'),
(36, '1522788677pexels-photo-279719.jpg', '2018-04-04 01:51:17', '2018-04-04 01:51:17'),
(37, '1526257734pexels-photo-271618.jpg', '2018-05-14 05:28:54', '2018-05-14 05:28:54'),
(38, '1526257861pexels-photo-276551.jpeg', '2018-05-14 05:31:01', '2018-05-14 05:31:01'),
(39, '1526257996pexels-photo-273843.jpg', '2018-05-14 05:33:16', '2018-05-14 05:33:16'),
(40, '1526519762pexels-photo-263189.jpeg', '2018-05-17 06:16:02', '2018-05-17 06:16:02'),
(41, '1526519937pexels-photo-271753.jpeg', '2018-05-17 06:18:57', '2018-05-17 06:18:57'),
(42, '1526520079pexels-photo-257344.jpeg', '2018-05-17 06:21:19', '2018-05-17 06:21:19'),
(43, '1526522366pexels-photo-271722.jpg', '2018-05-17 06:59:26', '2018-05-17 06:59:26'),
(44, '1526522488pexels-photo-276508.jpg', '2018-05-17 07:01:28', '2018-05-17 07:01:28'),
(45, '1526522618pexels-photo-276551.jpeg', '2018-05-17 07:03:38', '2018-05-17 07:03:38'),
(46, '1526522809pexels-photo-276700.jpeg', '2018-05-17 07:06:49', '2018-05-17 07:06:49'),
(47, '1526523218pexels-photo-276511.jpg', '2018-05-17 07:13:38', '2018-05-17 07:13:38'),
(48, '1526523393pexels-photo-276724.jpeg', '2018-05-17 07:16:33', '2018-05-17 07:16:33'),
(49, '1526523545pexels-photo-709767.png', '2018-05-17 07:19:05', '2018-05-17 07:19:05'),
(50, '1526523820pexels-photo-279607.jpeg', '2018-05-17 07:23:40', '2018-05-17 07:23:40'),
(51, '1526524107pexels-photo-276715.jpeg', '2018-05-17 07:28:27', '2018-05-17 07:28:27'),
(52, '1526524294pexels-photo-342800.jpg', '2018-05-17 07:31:34', '2018-05-17 07:31:34'),
(53, '1526524449pexels-photo-545046.jpg', '2018-05-17 07:34:09', '2018-05-17 07:34:09'),
(54, '1526524609pexels-photo-279719.jpg', '2018-05-17 07:36:49', '2018-05-17 07:36:49'),
(55, '1526524856pexels-photo-276551.jpeg', '2018-05-17 07:40:56', '2018-05-17 07:40:56'),
(56, '1526525131pexels-photo-279607.jpeg', '2018-05-17 07:45:31', '2018-05-17 07:45:31'),
(57, '1526525357pexels-photo-276554.jpg', '2018-05-17 07:49:17', '2018-05-17 07:49:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `extra_photo_fours`
--
ALTER TABLE `extra_photo_fours`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `extra_photo_fours`
--
ALTER TABLE `extra_photo_fours`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
