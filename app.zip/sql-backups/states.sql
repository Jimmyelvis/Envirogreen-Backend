-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `abbrev` varchar(3) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `abbrev`, `created_at`, `updated_at`) VALUES
(1, 'Alabama', 'AL', '2018-05-17 03:19:06', '2018-05-17 03:19:06'),
(2, 'Alaska', 'AK', '2018-05-17 03:20:12', '2018-05-17 03:20:12'),
(3, 'Arizona ', 'AZ', '2018-05-17 03:21:05', '2018-05-17 03:21:05'),
(4, 'Arkansas ', 'AR', '2018-05-17 03:21:19', '2018-05-17 03:21:19'),
(5, 'California ', 'CA', '2018-05-17 03:21:28', '2018-05-17 03:21:28'),
(6, 'Colorado ', 'CO', '2018-05-17 03:21:40', '2018-05-17 03:21:40'),
(7, 'Connecticut ', 'CT', '2018-05-17 03:21:50', '2018-05-17 03:21:50'),
(8, 'Delaware ', 'DE', '2018-05-17 03:22:01', '2018-05-17 03:22:01'),
(9, 'Florida ', 'FL', '2018-05-17 03:22:09', '2018-05-17 03:22:09'),
(10, 'Georgia ', 'GA', '2018-05-17 03:22:40', '2018-05-17 03:22:40'),
(11, 'Hawaii ', 'HI', '2018-05-17 03:22:51', '2018-05-17 03:22:51'),
(12, 'Idaho ', 'ID', '2018-05-17 03:23:01', '2018-05-17 03:23:01'),
(13, 'Illinois ', 'IL', '2018-05-17 03:23:13', '2018-05-17 03:23:13'),
(14, 'Indiana ', 'IN', '2018-05-17 03:23:25', '2018-05-17 03:23:25'),
(15, 'Iowa ', 'IA', '2018-05-17 03:23:36', '2018-05-17 03:23:36'),
(16, 'Kansas ', 'KS', '2018-05-17 03:23:48', '2018-05-17 03:23:48'),
(17, 'Kentucky ', 'KY', '2018-05-17 03:24:02', '2018-05-17 03:24:02'),
(18, 'Louisiana ', 'LA', '2018-05-17 03:24:18', '2018-05-17 03:24:18'),
(19, 'Maine ', 'ME', '2018-05-17 03:24:31', '2018-05-17 03:24:31'),
(20, 'Maryland ', 'MD', '2018-05-17 03:24:42', '2018-05-17 03:24:42'),
(21, 'Massachusetts ', 'MA', '2018-05-17 03:24:56', '2018-05-17 03:24:56'),
(22, 'Michigan ', 'MI', '2018-05-17 03:25:21', '2018-05-17 03:25:21'),
(23, 'Minnesota ', 'MN', '2018-05-17 03:25:32', '2018-05-17 03:25:32'),
(24, 'Mississippi ', 'MS', '2018-05-17 03:25:44', '2018-05-17 03:25:44'),
(25, 'Missouri ', 'MO', '2018-05-17 03:25:57', '2018-05-17 03:25:57'),
(26, 'Montana ', 'MT', '2018-05-17 03:26:07', '2018-05-17 03:26:07'),
(27, 'Nebraska ', 'NE', '2018-05-17 03:26:21', '2018-05-17 03:26:21'),
(28, 'Nevada ', 'NV', '2018-05-17 03:26:35', '2018-05-17 03:26:35'),
(29, 'New Hampshire', 'NH', '2018-05-17 03:26:52', '2018-05-17 03:26:52'),
(30, 'New Jersey', 'NJ', '2018-05-17 03:27:06', '2018-05-17 03:27:06'),
(31, 'New Mexico', 'NM', '2018-05-17 03:27:21', '2018-05-17 03:27:21'),
(32, 'New York', 'NY', '2018-05-17 03:27:33', '2018-05-17 03:27:33'),
(33, 'North Carolina', 'NC', '2018-05-17 03:27:53', '2018-05-17 03:27:53'),
(34, 'North Dakota ', 'ND', '2018-05-17 03:28:09', '2018-05-17 03:28:09'),
(35, 'Ohio ', 'OH', '2018-05-17 03:28:19', '2018-05-17 03:28:19'),
(36, 'Oklahoma ', 'OK', '2018-05-17 03:28:32', '2018-05-17 03:28:32'),
(37, 'Oregon ', 'OR', '2018-05-17 03:28:44', '2018-05-17 03:28:44'),
(38, 'Pennsylvania ', 'PA', '2018-05-17 03:29:20', '2018-05-17 03:29:20'),
(39, 'Rhode Island', 'RI', '2018-05-17 03:29:37', '2018-05-17 03:29:37'),
(40, 'South Carolina', 'SC', '2018-05-17 03:29:48', '2018-05-17 03:29:48'),
(41, 'South Dakota', 'SD', '2018-05-17 03:29:59', '2018-05-17 03:29:59'),
(42, 'Tennessee ', 'TN', '2018-05-17 03:30:10', '2018-05-17 03:30:10'),
(43, 'Texas ', 'TX', '2018-05-17 03:30:24', '2018-05-17 03:30:24'),
(44, 'Utah ', 'UT', '2018-05-17 03:30:34', '2018-05-17 03:30:34'),
(45, 'Vermont ', 'VT', '2018-05-17 03:30:43', '2018-05-17 03:30:43'),
(46, 'Virginia ', 'VA', '2018-05-17 03:30:56', '2018-05-17 03:30:56'),
(47, 'Washington ', 'WA', '2018-05-17 03:31:07', '2018-05-17 03:31:07'),
(48, 'West Virginia', 'WV', '2018-05-17 03:31:20', '2018-05-17 03:31:20'),
(49, 'Wisconsin ', 'WI', '2018-05-17 03:31:31', '2018-05-17 03:31:31'),
(50, 'Wyoming ', 'WY', '2018-05-17 03:31:42', '2018-05-17 03:31:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
