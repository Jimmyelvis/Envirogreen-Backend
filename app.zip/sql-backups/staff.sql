-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `position_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `role_id`, `position_id`, `name`, `photo`, `bio`, `email`, `phone`, `skype`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Sam Kerrigan', '1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora eius earum laudantium et consequatur quidem. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora eius earum laudantium et consequatur quidem. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora eius earum laudantium et consequatur quidem.', 'samker@envirogreen.com', 5555555, 'Samker', '123', NULL, NULL, NULL),
(2, 1, 1, 'Jake Kerr', '2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum, ab, accusantium. Veritatis tenetur expedita laboriosam fugit exercitationem, a nesciunt quidem, nulla repellendus doloribus mollitia hic sequi dolor! Aperiam ad nostrum, vel quibusdam, ratione accusantium officiis laborum eum a, molestiae minima nobis dolorum unde dolores, ab. Ullam molestiae iste aliquam veritatis nulla et provident praesentium, voluptates quidem, quod, natus, id deserunt facere eaque. Odit, aliquam culpa excepturi explicabo sed molestias maiores veritatis laborum, facilis beatae corporis vitae eveniet corrupti, delectus cupiditate non illo. Veritatis soluta ab provident nisi quia odit, recusandae tenetur. Sapiente quibusdam magnam pariatur ex id temporibus sequi tempora', 'jakekerr@envirogreen.com', 5555555, 'jakekerr', '123', NULL, NULL, NULL),
(3, 2, 2, 'Annete Pounder', '3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora eius earum laudantium et consequatur quidem.', 'Pounder@envirogreen.com', 6677679, 'Pounder', '123', NULL, NULL, NULL),
(4, 2, 3, 'Steven Smith', '4', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora eius earum laudantium et consequatur quidem.\r\n\r\n', 'smith@envirogreen.com', 7878787, 'smithy', '123', NULL, NULL, NULL),
(5, 1, 4, 'Pete Mason\r\n', '5', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora eius earum laudantium et consequatur quidem.\r\n\r\n', 'Mason@envirogreen.com', 4567895, 'mason', '123', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_email_unique` (`email`),
  ADD KEY `staff_role_id_index` (`role_id`),
  ADD KEY `staff_position_id_index` (`position_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
