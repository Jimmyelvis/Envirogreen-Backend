-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `extra_photo_ones`
--

CREATE TABLE `extra_photo_ones` (
  `id` int(10) UNSIGNED NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `extra_photo_ones`
--

INSERT INTO `extra_photo_ones` (`id`, `file`, `created_at`, `updated_at`) VALUES
(42, '1522460183kitchen-stove-sink-kitchen-counter-349749.jpg', '2018-03-31 06:36:23', '2018-03-31 06:36:23'),
(43, '1522460535pexels-photo-275484.jpeg', '2018-03-31 06:42:15', '2018-03-31 06:42:15'),
(44, '1522460785pexels-photo-121668.jpg', '2018-03-31 06:46:25', '2018-03-31 06:46:25'),
(45, '1522460941pexels-photo-106936.jpeg', '2018-03-31 06:49:01', '2018-03-31 06:49:01'),
(46, '1522461134pexels-photo-210265.jpg', '2018-03-31 06:52:14', '2018-03-31 06:52:14'),
(47, '1522461277pexels-photo-210265.jpg', '2018-03-31 06:54:37', '2018-03-31 06:54:37'),
(48, '1522785654pexels-photo-238377.jpeg', '2018-04-04 01:00:54', '2018-04-04 01:00:54'),
(49, '1522788571kitchen-stove-sink-kitchen-counter-349749.jpg', '2018-04-04 01:49:31', '2018-04-04 01:49:31'),
(50, '1522788677pexels-photo-276625.jpg', '2018-04-04 01:51:17', '2018-04-04 01:51:17'),
(51, '1526257734living-room-couch-interior-room-584399.jpeg', '2018-05-14 05:28:54', '2018-05-14 05:28:54'),
(52, '1526257860pexels-photo-271696.jpg', '2018-05-14 05:31:01', '2018-05-14 05:31:01'),
(53, '1526257996pexels-photo-271696.jpg', '2018-05-14 05:33:16', '2018-05-14 05:33:16'),
(54, '1526519762pexels-photo-189333.jpeg', '2018-05-17 06:16:02', '2018-05-17 06:16:02'),
(55, '1526519937kitchen-stove-sink-kitchen-counter-349749.jpg', '2018-05-17 06:18:57', '2018-05-17 06:18:57'),
(56, '1526520079pexels-photo-271696.jpg', '2018-05-17 06:21:19', '2018-05-17 06:21:19'),
(57, '1526522366pexels-photo-271654.jpeg', '2018-05-17 06:59:26', '2018-05-17 06:59:26'),
(58, '1526522488pexels-photo-269218.jpeg', '2018-05-17 07:01:28', '2018-05-17 07:01:28'),
(59, '1526522618pexels-photo-273669.jpeg', '2018-05-17 07:03:38', '2018-05-17 07:03:38'),
(60, '1526522809pexels-photo-276554.jpg', '2018-05-17 07:06:49', '2018-05-17 07:06:49'),
(61, '1526523217pexels-photo-210265.jpg', '2018-05-17 07:13:37', '2018-05-17 07:13:37'),
(62, '1526523393pexels-photo-273669.jpeg', '2018-05-17 07:16:33', '2018-05-17 07:16:33'),
(63, '1526523545pexels-photo-276700.jpeg', '2018-05-17 07:19:05', '2018-05-17 07:19:05'),
(64, '1526523820pexels-photo-271618.jpg', '2018-05-17 07:23:40', '2018-05-17 07:23:40'),
(65, '1526524107kitchen-stove-sink-kitchen-counter-349749.jpg', '2018-05-17 07:28:27', '2018-05-17 07:28:27'),
(66, '1526524294pexels-photo-276715.jpeg', '2018-05-17 07:31:34', '2018-05-17 07:31:34'),
(67, '1526524449pexels-photo-276724.jpeg', '2018-05-17 07:34:09', '2018-05-17 07:34:09'),
(68, '1526524609pexels-photo-262048.jpg', '2018-05-17 07:36:49', '2018-05-17 07:36:49'),
(69, '1526524856pexels-photo-261410.jpeg', '2018-05-17 07:40:56', '2018-05-17 07:40:56'),
(70, '1526525131pexels-photo-271618.jpg', '2018-05-17 07:45:31', '2018-05-17 07:45:31'),
(71, '1526525357pexels-photo-265004.jpeg', '2018-05-17 07:49:17', '2018-05-17 07:49:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `extra_photo_ones`
--
ALTER TABLE `extra_photo_ones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `extra_photo_ones`
--
ALTER TABLE `extra_photo_ones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
