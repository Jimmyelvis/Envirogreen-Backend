-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `photo_staffs`
--

CREATE TABLE `photo_staffs` (
  `id` int(10) UNSIGNED NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `photo_staffs`
--

INSERT INTO `photosstaff` (`id`, `file`, `created_at`, `updated_at`) VALUES
(1, 'sam.jpg', NULL, NULL),
(2, 'luger.jpg', NULL, NULL),
(9, '1522274393r32fdewq2fdc3eq.jpg', '2018-03-29 02:59:53', '2018-03-29 02:59:53'),
(10, '1522274409454564fw.jpg', '2018-03-29 03:00:09', '2018-03-29 03:00:09'),
(11, '1522457745fdgsdfg.jpg', '2018-03-31 05:55:45', '2018-03-31 05:55:45'),
(12, '152245777232133.jpg', '2018-03-31 05:56:12', '2018-03-31 05:56:12'),
(13, '15224578421522274393r32fdewq2fdc3eq.jpg', '2018-03-31 05:57:22', '2018-03-31 05:57:22'),
(14, '1522457925247885.jpg', '2018-03-31 05:58:45', '2018-03-31 05:58:45'),
(15, '1522457969247885.jpg', '2018-03-31 05:59:29', '2018-03-31 05:59:29'),
(16, '152245804723r2dqd32wq.jpg', '2018-03-31 06:00:47', '2018-03-31 06:00:47'),
(17, '1522458129fwersf.jpg', '2018-03-31 06:02:09', '2018-03-31 06:02:09'),
(18, '152245830243tf3t3e4wr.jpg', '2018-03-31 06:05:02', '2018-03-31 06:05:02'),
(19, '15224583841515033345233254.jpg', '2018-03-31 06:06:24', '2018-03-31 06:06:24'),
(20, '152245845746465456446.jpg', '2018-03-31 06:07:37', '2018-03-31 06:07:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `photo_staffs`
--
ALTER TABLE `photo_staffs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `photo_staffs`
--
ALTER TABLE `photo_staffs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
