-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2024 at 11:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `position_id` int(10) UNSIGNED DEFAULT NULL,
  `photoStaff_id` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `role_id`, `position_id`, `photoStaff_id`, `bio`, `phone`, `skype`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Sam Kerrigan', 1, 1, '1', 'Lorem ipsum dolor amet twee elit shoreditch palo santo labore gluten-free craft beer literally photo booth 3 wolf moon nulla. Mlkshk edison bulb raw denim pickled adipisicing velit minim bushwick wolf. Twee bespoke microdosing waistcoat. Squid 8-bit dolore fam cupidatat disrupt. In paleo +1, hammock bicycle rights marfa cupidatat mlkshk ramps dolore. Crucifix ethical la croix vexillologist. Magna paleo poke vice raclette chambray.', '4137888888', 'sam', 'samker@envirogreen.com', '$2y$10$Z0VEnobYEJzB3kRgZqoUhO5n5rPn9EduxN1kH.3q41dEFyz007rdy', 'gQjBnyuaDm6xdcSNF5WdXo6z186IHd3jSWs92kQLYtdqYFlJS6bbVMKNiHib', '2018-03-06 09:03:39', '2021-12-31 10:42:32'),
(2, 'Mike Luger', 1, 1, '2', 'Coloring book umami organic, gluten-free consectetur banh mi humblebrag poutine street art shabby chic. Yr blue bottle man braid beard cupidatat neutra. Ipsum poke ullamco, occaecat tote bag selvage hot chicken coloring book art party ea. Distillery voluptate next level banh mi.', '4125555555', 'luger', 'luger@envirogreen.com', '$2y$10$AD/pkMnE7yU89tdLCgka/ecb5l1oszW02flLQM8qw9pl8udq9v/z2', NULL, '2018-03-06 09:05:45', '2018-03-06 09:05:45'),
(3, 'Jane Kalo', 2, 2, '10', 'Kale chips occupy enamel pin, dolore austin chicharrones pickled quis. Whatever dolore cupidatat ut, williamsburg kickstarter wolf wayfarers direct trade authentic exercitation squid man braid keytar. Trust fund try-hard umami irony food truck deep v. Direct trade art party scenester vice, dolor food truck irony celiac XOXO sunt. Mumblecore austin craft beer dolore brunch, poke crucifix in. Raw denim ullamco 3 wolf moon ugh. Nostrud 90\'s prism pariatur kogi taxidermy.', '413-569-5569', 'jane', 'jane@envirogreen.com', 'panther', NULL, '2018-03-06 09:38:06', '2018-03-29 03:00:09'),
(4, 'Dylan Cougar', 1, 4, '11', 'Kale chips occupy enamel pin, dolore austin chicharrones pickled quis. Whatever dolore cupidatat ut, williamsburg kickstarter wolf wayfarers direct trade authentic exercitation squid man braid keytar. Trust fund try-hard umami irony food truck deep v. Direct trade art party scenester vice, dolor food truck irony celiac XOXO sunt. Mumblecore austin craft beer dolore brunch, poke crucifix in. Raw denim ullamco 3 wolf moon ugh. Nostrud 90\'s prism pariatur kogi taxidermy.', '413-669-6969', 'dylan', 'dylancougar@envirogreen.com', '$2y$10$eiY3AIVMIpoLF8W4V0SiFusqMYjsCcm1368ChGwIK/gJm00vXTRTy', NULL, '2018-03-06 09:41:17', '2018-03-31 05:55:45'),
(6, 'Ana Hartman', 2, 2, '12', 'Pour-over pickled pitchfork fanny pack laborum la croix. Mixtape dolor enim, hashtag culpa green juice organic yuccie sustainable. Cred sed locavore chartreuse. Non roof party brooklyn woke consequat vape blog dolore la croix post-ironic kitsch flexitarian vaporware heirloom ut. Mumblecore try-hard laborum kale chips hoodie godard labore tacos meggings banh mi nulla.', '5555555', 'hart', 'hart@envirogreen.com', '$2y$10$U/Mz1cdLBo0T7ujkiLWGfOPhAqEuFgYBofNS2r4ZKmZ3jbBYA4az2', NULL, '2018-03-31 05:56:12', '2018-03-31 05:56:12'),
(7, 'Jane Brisbane', 2, 2, '13', 'Fixie shoreditch chartreuse affogato, duis taiyaki enim taxidermy leggings vinyl. Jianbing small batch sint hammock XOXO tattooed ennui kogi. Yuccie hashtag cronut try-hard proident esse culpa selvage succulents lorem lyft. Artisan edison bulb wayfarers, hot chicken est keffiyeh cupidatat green juice commodo excepteur culpa adipisicing mollit. Photo booth humblebrag helvetica, biodiesel VHS pok pok selvage ennui. Meh elit air plant four dollar toast ennui asymmetrical fugiat cred laborum. Before they sold out lomo bicycle rights gastropub sustainable polaroid scenester blue bottle et.', '5555555', 'jane', 'brisbane@envirogreen.com', '$2y$10$Q9jIXr.oXA6mwqGWJrlxvuTY.nDwcPoY2TgHOYdHP1Wce9UQh2ILK', NULL, '2018-03-31 05:57:22', '2018-03-31 05:57:22'),
(9, 'Steven Sherner', 2, 3, '15', 'Coloring book umami organic, gluten-free consectetur banh mi humblebrag poutine street art shabby chic. Yr blue bottle man braid beard cupidatat neutra. Ipsum poke ullamco, occaecat tote bag selvage hot chicken coloring book art party ea. Distillery voluptate next level banh mi.', '5555555', 'shern', 'shern@envirogreen.com', '$2y$10$EB/B6T6SqEuvcvZsnPNypuCLvK7GgY/8ZiLaSuCZRv.Z5olGtSYbS', NULL, '2018-03-31 05:59:29', '2018-03-31 05:59:29'),
(10, 'Tommy Kane', 2, 3, '16', 'Non roof party brooklyn woke consequat vape blog dolore la croix post-ironic kitsch flexitarian vaporware heirloom ut. Mumblecore try-hard laborum kale chips hoodie godard labore tacos meggings banh mi nulla.', '5555555', 'kane', 'kane@envirogreen.com', '$2y$10$yYj7rS2Q2wnlZu5KS7OpwuY6G2BzXLYGwrMnh91uokQCGDs02.hF.', '3LGQRXDTsJuUBSY85DRk0otCfzKn1c9JdHEkK8EN0WxkzJwQu0I4pwoxl8l5', '2018-03-31 06:00:47', '2018-03-31 06:08:45'),
(11, 'Randy Lords', 2, 3, '17', 'Meh elit air plant four dollar toast ennui asymmetrical fugiat cred laborum. Before they sold out lomo bicycle rights gastropub sustainable polaroid scenester blue bottle et.', '5555555', 'randy', 'randy@envirogreen.com', '$2y$10$5p10aCYXEvtrzpKeENxlQ.i2klqtAl2hw69GDyxkL0BNMNybzFPHa', NULL, '2018-03-31 06:02:09', '2018-03-31 06:02:09'),
(12, 'Tammy Landis', 2, 3, '18', 'Kale chips occupy enamel pin, dolore austin chicharrones pickled quis. Whatever dolore cupidatat ut, williamsburg kickstarter wolf wayfarers direct trade authentic exercitation squid man braid keytar. Trust fund try-hard umami irony food truck deep v. Direct trade art party scenester vice, dolor food truck irony celiac XOXO sunt. Mumblecore austin craft beer dolore brunch, poke crucifix in. Raw denim ullamco 3 wolf moon ugh. Nostrud 90\'s prism pariatur kogi taxidermy.', '55544454', 'landis', 'landis@envirogreen.com', '$2y$10$8nftcl0ChTHw.bglKShiEu4YJInlrBOSd6MeL9zkTWxLynID9FlB.', NULL, '2018-03-31 06:05:02', '2018-03-31 06:05:02'),
(13, 'Greg Handler', 2, 2, '19', 'Direct trade art party scenester vice, dolor food truck irony celiac XOXO sunt. Mumblecore austin craft beer dolore brunch, poke crucifix in. Raw denim ullamco 3 wolf moon ugh. ', '7777777', 'greg', 'greg@envirogreen.com', '$2y$10$NoFIPDSPbEVOlbFkGSHfsOm3aGQjiicR5eW6EXuqTz0DSLjt4xi7m', NULL, '2018-03-31 06:06:24', '2018-03-31 06:06:24'),
(14, 'Johnny Bristol', 1, 4, '20', 'Coloring book umami organic, gluten-free consectetur banh mi humblebrag poutine street art shabby chic. Yr blue bottle man braid beard cupidatat neutra. Ipsum poke ullamco, occaecat tote bag selvage hot chicken coloring book art party ea. Distillery voluptate next level banh mi.', '9999999', 'bristol', 'bristol@envirogreen.com', '$2y$10$6OZxGC1/F/u/DdHez5yJl.aCSdJCwfvBxa.kjoo72SfvAqKCscKQm', NULL, '0000-00-00 00:00:00', '2018-03-31 06:07:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_index` (`role_id`),
  ADD KEY `users_position_id_index` (`position_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
