-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2024 at 12:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enviro-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `listings`
--

CREATE TABLE `listings` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `street` varchar(255) NOT NULL,
  `city_id` int(10) NOT NULL,
  `state_id` int(10) NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `beds` int(10) UNSIGNED NOT NULL,
  `baths` int(10) UNSIGNED NOT NULL,
  `sqft` int(10) UNSIGNED NOT NULL,
  `fullpic_id` int(10) UNSIGNED NOT NULL,
  `extrapicone_id` varchar(255) NOT NULL,
  `extrapictwo_id` varchar(255) NOT NULL,
  `extrapicthree_id` varchar(255) NOT NULL,
  `extrapicfour_id` varchar(255) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `descrip` text NOT NULL,
  `feat_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `listings`
--

INSERT INTO `listings` (`id`, `category_id`, `street`, `city_id`, `state_id`, `price`, `beds`, `baths`, `sqft`, `fullpic_id`, `extrapicone_id`, `extrapictwo_id`, `extrapicthree_id`, `extrapicfour_id`, `user_id`, `descrip`, `feat_id`, `created_at`, `updated_at`) VALUES
(1, 1, '24 Moonlight Drive', 1, 21, 300000, 5, 1, 3000, 77, '54', '46', '40', '40', 9, 'Elegant custom home offers unparalleled craftsmanship and exceptional \r\namenities! This French-inspired design is truly remarkable inside and out. \r\nFeatures include cherry cabinets, quartz countertops, crown molding, custom \r\nwindows provide plenty of natural lighting, expansive decking (1000 sq. ft.), \r\ngourmet kitchen with island (great for entertaining), gorgeous master suite, \r\nden, storage, plus STUNNING views ', 0, '2018-05-17 06:16:02', '2018-05-17 06:16:02'),
(2, 1, '59 Blue Moon Road', 2, 21, 350000, 6, 2, 4000, 78, '55', '47', '41', '41', 10, 'Masterful design and modern luxury are uniquely embodied in this 4 \r\nbedroom 4.5 bath Duplex Penthouse with a 4500 SF wraparound terrace \r\natop Sky Lofts Condominium. This one-of-a-kind glass house, created by New \r\nYork architect James Carpenter who designed 7 World Trade Center, is \r\nsheathed in high-performance, museum-quality insulated glass atop an \r\nhistoric Art Deco loft building in the heart of Tribeca. The sun and \r\ntemperature-controlled glass envelope of its 7500 SF interior was tastefully \r\ndesigned with the top art collector in mind. Unobstructed 360 views from \r\nthis penthouse are truly unparalleled, and include vistas of the Freedom \r\nTower, Empire State Building and Hudson River.', 0, '2018-05-17 06:18:57', '2018-05-17 06:18:57'),
(3, 1, '1969 Sunnyvale Road', 4, 21, 450000, 7, 3, 4000, 79, '56', '48', '42', '42', 11, 'Living is easy in this impressive, generously spacious residence with Delta \r\nviews and access.\r\n\r\nThe open floor plan encompasses four spacious bedrooms with plenty of \r\nroom for study, sleep and storage, four and a half luxurious bathrooms, and a \r\nsleek and stylish gourmet kitchen that flows through to the dining room.  The \r\nexpansive living room opens up to a spacious rear patio with pool and spa and \r\nprivate boat dock on San Joaquin Delta. The master bedroom, complete with \r\nwalk-in closet and ensuite, ensures parents have a private space where they \r\ncan enjoy the Delta views on their private balcony.\r\n\r\nPerfect for anyone, this home is ideally positioned to enjoy summers on the \r\nDelta.  Truly resort style living in Brookside Country Club Estates.', 0, '2018-05-17 06:21:19', '2018-05-17 06:21:19'),
(4, 1, '73 Darkville Ave', 5, 21, 140000, 4, 1, 2000, 80, '57', '49', '43', '43', 12, 'This immaculate, professionally-designed 2-story condo with a private deck \r\nand patio invites comfort, and exudes modern elegance. With 2 bedrooms, 2 \r\nand a half baths, generous living space and stylish finishes, you\'ll enjoy a \r\nperfect setting for relaxing and entertaining.\r\n\r\nBeautiful mahogany hardwood floors and plenty of natural night flow \r\nthroughout the home\'s open, airy layout. Other special highlights include a \r\ncharming gas fireplace, rich exposed brick, chic recessed lighting and ceiling \r\nfans, a Kenmore Elite washer/dryer, marble baths, tons of storage space, and \r\nready-for-cable wiring in all rooms.', 0, '2018-05-17 06:59:26', '2018-05-17 06:59:26'),
(5, 1, '488 Mountain Way', 6, 7, 103000, 4, 1, 3000, 81, '58', '50', '44', '44', 11, 'This immaculate, professionally-designed 2-story condo with a private deck \r\nand patio invites comfort, and exudes modern elegance. With 2 bedrooms, 2 \r\nand a half baths, generous living space and stylish finishes, you\'ll enjoy a \r\nperfect setting for relaxing and entertaining.\r\n\r\nBeautiful mahogany hardwood floors and plenty of natural night flow \r\nthroughout the home\'s open, airy layout. Other special highlights include a \r\ncharming gas fireplace, rich exposed brick, chic recessed lighting and ceiling \r\nfans, a Kenmore Elite washer/dryer, marble baths, tons of storage space, and \r\nready-for-cable wiring in all rooms.', 0, '2018-05-17 07:01:28', '2018-05-17 07:01:28'),
(6, 1, '669 Blue Ocean Drive', 10, 7, 400000, 8, 3, 4000, 82, '59', '51', '45', '45', 10, 'Living is easy in this impressive, generously spacious residence with Delta \r\nviews and access.\r\n\r\nThe open floor plan encompasses four spacious bedrooms with plenty of \r\nroom for study, sleep and storage, four and a half luxurious bathrooms, and a \r\nsleek and stylish gourmet kitchen that flows through to the dining room.  The \r\nexpansive living room opens up to a spacious rear patio with pool and spa and \r\nprivate boat dock on San Joaquin Delta. The master bedroom, complete with \r\nwalk-in closet and ensuite, ensures parents have a private space where they \r\ncan enjoy the Delta views on their private balcony.', 0, '2018-05-17 07:03:38', '2018-05-17 07:03:38'),
(7, 1, '56 Morning Breeze Street', 17, 7, 300000, 5, 2, 3000, 83, '60', '52', '46', '46', 10, 'Paradise at The Point! This luxurious 5 bedroom 4.5 bath Dienst-built estate on \r\nthe Lake Norman peninsula is a dream home in a high-end community that\'s \r\nhome to Trump National Golf Club. Spanning over 4900 SF, this magnificent \r\nwaterfront residence graced by soaring ceilings and wall-to-wall windows is a \r\nhaven for gazing at Lake Norman views from multiple vantage points. The grand \r\nentryway with a sweeping staircase draws you into a voluminous layout made \r\nfor entertaining. ', 0, '2018-05-17 07:06:49', '2018-05-17 07:06:49'),
(8, 1, '34 Greensville Road', 16, 45, 230000, 4, 1, 3000, 84, '61', '53', '47', '47', 9, 'It won’t be easy to click out of holiday mode in this stylishly contemporary \r\nresidence for the modern pleasure-seeker.\r\n\r\nCool, calm and sophisticated with a youthful edge, this functional home is \r\nenveloped in light and comfort. Crisp white walls, timber floors and high \r\nceilings create a style as timeless as the sparkling ocean view. The calming sea \r\nvista, captured through the extensive use of glass, will help you forget your \r\ncity stress.\r\n\r\nThis house screams ‘designer’ and will reflect the personality and taste of \r\nthose accustomed to the best in quality design, finishes and lifestyle', 0, '2018-05-17 07:13:38', '2018-05-17 07:13:38'),
(9, 1, '718 White Clouds Ave', 17, 7, 300000, 5, 2, 3000, 85, '62', '54', '48', '48', 13, 'This immaculately presented apartment is set amongst manicured grounds \r\nwithin a private and secure complex. As a resident you will have access to \r\nlifestyle amenities including a lap pool, gymnasium, communal terraces, \r\nconcierge service and basement parking.\r\n\r\nThe floorplan incorporates 2 bedrooms, the main with built-in robe and \r\nensuite, a study nook, modern kitchen with quality appliances, luxurious \r\nbathroom, a cleverly concealed laundry and a spacious living/dining area. The \r\ngenerously proportioned interior flows effortlessly from the open-plan living \r\nspace to the private covered balcony from which you can admire the views of \r\nthe garden and beyond.\r\n\r\nWith its warm sense of community, and only moments to shops, eateries and \r\ntransport this home provides all the elements for relaxing, comfortable and \r\neasycare living.', 0, '2018-05-17 07:16:33', '2018-05-17 07:16:33'),
(10, 1, '45 Forest Drive', 2, 21, 163000, 3, 1, 2000, 86, '63', '55', '49', '49', 7, 'This cozy cottage is nestled against a spectacular coastal backdrop with an \r\nunbroken view of the sea and a faraway coastline. With an environmentally \r\nconscious design that maximizes home efficiency, this spectacular, modern \r\nfamily home provides plenty of space for entertaining. This truly is a dream \r\nabode for the growing family.', 0, '2018-05-17 07:19:05', '2018-05-17 07:19:05'),
(11, 1, '889 Woodsy Street', 1, 21, 180000, 3, 1, 2500, 88, '64', '56', '50', '50', 4, 'Embrace the spirit of DIY with this original cottage occupying a peaceful street \r\nposition. This charming weatherboard home features 3 roomy bedrooms and \r\nbright, open living spaces.\r\n\r\nThere’s plenty of potential for the savvy investor or first home buyer.', 0, '2018-05-17 07:23:40', '2018-05-17 07:24:28'),
(12, 1, '1645 Peachville Drive', 2, 21, 240500, 5, 1, 2300, 89, '65', '57', '51', '51', 6, 'The living is easy in this impressive, generously proportioned contemporary \r\nresidence with lake and ocean views, located within a level stroll to the sand \r\nand surf.\r\n\r\nThe floor plan encompasses four spacious bedrooms with plenty of room for \r\nstudy, sleep and storage, three luxurious bathrooms, and a sleek and stylish \r\nkitchen that flows through to the dining room and private rear patio. The \r\nmaster bedroom, complete with walk-in robe and ensuite, ensures parents \r\nhave a private space where they can enjoy the view.\r\n\r\nPerfect for a family or as a holiday retreat, this home is ideally positioned to \r\nenjoy the proximity to beaches, cafes and restaurants, shopping centre, and a \r\nselection of premier schools.', 0, '2018-05-17 07:28:27', '2018-05-17 07:28:27'),
(13, 1, '90 Granite Ave', 3, 21, 250000, 5, 1, 3000, 90, '66', '58', '52', '52', 12, 'The living is easy in this impressive, generously proportioned contemporary \r\nresidence with lake and ocean views, located within a level stroll to the sand \r\nand surf.\r\n\r\nThe floor plan encompasses four spacious bedrooms with plenty of room for \r\nstudy, sleep and storage, three luxurious bathrooms, and a sleek and stylish \r\nkitchen that flows through to the dining room and private rear patio. The \r\nmaster bedroom, complete with walk-in robe and ensuite, ensures parents \r\nhave a private space where they can enjoy the view.\r\n\r\nPerfect for a family or as a holiday retreat, this home is ideally positioned to \r\nenjoy the proximity to beaches, cafes and restaurants, shopping centre, and a \r\nselection of premier schools.', 0, '2018-05-17 07:31:34', '2018-05-17 07:31:34'),
(14, 1, '1968 Rocky Hill Road', 9, 7, 180000, 4, 1, 2000, 91, '67', '59', '53', '53', 9, 'The living is easy in this impressive, generously proportioned contemporary \r\nresidence with lake and ocean views, located within a level stroll to the sand \r\nand surf.\r\n\r\nThe floor plan encompasses four spacious bedrooms with plenty of room for \r\nstudy, sleep and storage, three luxurious bathrooms, and a sleek and stylish \r\nkitchen that flows through to the dining room and private rear patio. The \r\nmaster bedroom, complete with walk-in robe and ensuite, ensures parents \r\nhave a private space where they can enjoy the view.\r\n\r\nPerfect for a family or as a holiday retreat, this home is ideally positioned to \r\nenjoy the proximity to beaches, cafes and restaurants, shopping centre, and a \r\nselection of premier schools.', 0, '2018-05-17 07:34:09', '2018-05-17 07:34:09'),
(15, 1, '1969 Breezy Way', 12, 21, 330000, 5, 2, 4500, 92, '68', '60', '54', '54', 13, 'The living is easy in this impressive, generously proportioned contemporary \r\nresidence with lake and ocean views, located within a level stroll to the sand \r\nand surf.\r\n\r\nThe floor plan encompasses four spacious bedrooms with plenty of room for \r\nstudy, sleep and storage, three luxurious bathrooms, and a sleek and stylish \r\nkitchen that flows through to the dining room and private rear patio. The \r\nmaster bedroom, complete with walk-in robe and ensuite, ensures parents \r\nhave a private space where they can enjoy the view.\r\n\r\nPerfect for a family or as a holiday retreat, this home is ideally positioned to \r\nenjoy the proximity to beaches, cafes and restaurants, shopping centre, and a \r\nselection of premier schools.', 0, '2018-05-17 07:36:49', '2018-05-17 07:36:49'),
(16, 1, '68 Winter Drive', 18, 7, 465000, 7, 3, 4500, 93, '69', '61', '55', '55', 10, 'This immaculately presented apartment is set amongst manicured grounds \r\nwithin a private and secure complex. As a resident you will have access to \r\nlifestyle amenities including a lap pool, gymnasium, communal terraces, \r\nconcierge service and basement parking.\r\n\r\nThe floorplan incorporates 2 bedrooms, the main with built-in robe and \r\nensuite, a study nook, modern kitchen with quality appliances, luxurious \r\nbathroom, a cleverly concealed laundry and a spacious living/dining area. The \r\ngenerously proportioned interior flows effortlessly from the open-plan living \r\nspace to the private covered balcony from which you can admire the views of \r\nthe garden and beyond.\r\n\r\nWith its warm sense of community, and only moments to shops, eateries and \r\ntransport this home provides all the elements for relaxing, comfortable and \r\neasycare living', 0, '2018-05-17 07:40:56', '2018-05-17 07:40:56'),
(17, 1, '1071 Floral Street', 2, 21, 270600, 5, 1, 3200, 94, '70', '62', '56', '56', 6, 'This cozy cottage is nestled against a spectacular coastal backdrop with an \r\nunbroken view of the sea and a faraway coastline. With an environmentally \r\nconscious design that maximizes home efficiency, this spectacular, modern \r\nfamily home provides plenty of space for entertaining. This truly is a dream \r\nabode for the growing family.', 0, '2018-05-17 07:45:31', '2018-05-17 07:45:31'),
(18, 1, '545 Lightning Circle', 7, 21, 251000, 4, 1, 3000, 95, '71', '63', '57', '57', 12, 'Embrace the spirit of DIY with this original cottage occupying a peaceful street \r\nposition. This charming weatherboard home features 3 roomy bedrooms and \r\nbright, open living spaces.\r\n\r\nThere’s plenty of potential for the savvy investor or first home buyer.', 0, '2018-05-17 07:49:17', '2018-05-17 07:49:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `listings`
--
ALTER TABLE `listings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `listings_fullpic_id_index` (`fullpic_id`),
  ADD KEY `listings_extrapic_id_index` (`extrapicone_id`),
  ADD KEY `listings_agent_id_index` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `listings`
--
ALTER TABLE `listings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
